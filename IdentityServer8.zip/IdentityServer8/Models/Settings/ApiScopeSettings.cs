using System;

namespace IdentityServer8.Models.Settings;

public class ApiScopeSettings
{
    public string Name { get; set; }
    public string DisplayName { get; set; }
}
