using System;

namespace IdentityServer8.Models.Settings;

public class DefaultReturnUri
{
    public string ReturnUrl { get; set; }
}
