using System;

namespace IdentityServer8.Models.Settings;

public class OwnAccess
{
    public string Authority { get; set; }
    public string Audience { get; set; }
}
