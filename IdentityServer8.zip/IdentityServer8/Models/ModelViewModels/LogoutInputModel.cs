using System;

namespace IdentityServer8.Models.ModelViewModels;

public class LogoutInputModel
{
    public required string LogoutId { get; set; }
}
